require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
const cors = require('cors');
const EventEmitter = require('events'); // The Event Broker

const app = express();
app.use(cors());
app.use(express.json());

// Initialize the Event Broker
const aqiEmitter = new EventEmitter();

mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('MongoDB Connected'))
    .catch(err => console.error('MongoDB connection error:', err));

const stationSchema = new mongoose.Schema({
    name: String,
    lat: Number,
    lng: Number,
    aqi: String,
    pollutant: String,
    status: String,
    color: String,
    updatedAt: { type: Date, default: Date.now }
});
const Station = mongoose.model('Station', stationSchema);

function getAqiStatus(aqiValue) {
    const aqi = Number(aqiValue);
    if (isNaN(aqi)) return { status: 'Offline', color: '#808080' };
    if (aqi <= 50) return { status: 'Good', color: '#00e400' };
    if (aqi <= 100) return { status: 'Moderate', color: '#cccc00' };
    if (aqi <= 150) return { status: 'Unhealthy', color: '#ff7e00' };
    return { status: 'Very Unhealthy', color: '#ff0000' };
}

// 1. STANDARD ENDPOINT: Fetches map data
app.get('/api/map-aqi', async (req, res) => {
    try {
        const bounds = "14.35,120.85,14.80,121.15";
        const boundsUrl = `https://api.waqi.info/v2/map/bounds/?latlng=${bounds}&token=${process.env.WAQI_TOKEN}`;
        
        const boundsResponse = await axios.get(boundsUrl, { timeout: 8000 });
        const activeStations = boundsResponse.data?.data || [];

        if (activeStations.length > 0) {
            const mapData = activeStations.map(station => {
                const aqiData = getAqiStatus(station.aqi);
                
                // EVENT PRODUCER TRIGGER: Automatically emit alert if air is unhealthy
                if (Number(station.aqi) > 100) {
                    aqiEmitter.emit('unhealthy-air', {
                        station: station.station.name,
                        aqi: station.aqi,
                        status: aqiData.status
                    });
                }

                return {
                    name: station.station.name,
                    lat: station.lat,
                    lng: station.lon,
                    aqi: station.aqi,
                    pollutant: 'PM2.5',
                    status: aqiData.status,
                    color: aqiData.color
                };
            });

            await Station.deleteMany({});
            await Station.insertMany(mapData);
            return res.json(mapData);
        }
        const cached = await Station.find({});
        res.json(cached);
    } catch (error) {
        const cached = await Station.find({});
        res.json(cached);
    }
});

// 2. SSE ENDPOINT (Event Consumer Gateway)
app.get('/api/events', (req, res) => {
    // Set headers to keep the connection open indefinitely
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders(); // Establish the connection immediately

    // Define what happens when the broker shouts
    const sendAlert = (alertData) => {
        res.write(`data: ${JSON.stringify(alertData)}\n\n`);
    };

    // Subscribe to the broker
    aqiEmitter.on('unhealthy-air', sendAlert);

    // Clean up when the user closes their browser tab
    req.on('close', () => {
        aqiEmitter.off('unhealthy-air', sendAlert);
    });
});

// 3. SIMULATION ENDPOINT (For presentation/testing)
app.post('/api/simulate-alert', (req, res) => {
    aqiEmitter.emit('unhealthy-air', {
        station: "Simulated Test City",
        aqi: 155,
        status: "Very Unhealthy"
    });
    res.json({ message: "Simulated alert dispatched!" });
});

app.listen(process.env.PORT || 5000, () => console.log('Backend mapping server active.'));